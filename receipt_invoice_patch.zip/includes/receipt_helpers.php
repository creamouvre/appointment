<?php
function generate_receipt_no(int $appointmentId): string {
    return 'RCPT-' . date('Ymd') . '-' . str_pad((string)$appointmentId, 5, '0', STR_PAD_LEFT);
}

function ensure_receipt_number(array $appointment): string {
    global $pdo;

    if (!empty($appointment['receipt_no'])) {
        return $appointment['receipt_no'];
    }

    $receiptNo = generate_receipt_no((int)$appointment['id']);

    $stmt = $pdo->prepare("UPDATE appointments SET receipt_no=? WHERE id=? AND clinic_id=?");
    $stmt->execute([$receiptNo, $appointment['id'], $appointment['clinic_id']]);

    return $receiptNo;
}

function receipt_message(array $appointment, array $clinic): string {
    $receiptNo = $appointment['receipt_no'] ?? generate_receipt_no((int)$appointment['id']);
    $amount = number_format((float)$appointment['payment_amount'], 2);
    $service = $appointment['service_name'] ?: 'Appointment';

    return "Hello {$appointment['full_name']}, payment received.\n"
        . "Receipt No: {$receiptNo}\n"
        . "Clinic: {$clinic['clinic_name']}\n"
        . "Service: {$service}\n"
        . "Amount: KES {$amount}\n"
        . "Date: " . date('Y-m-d') . "\n"
        . "Thank you.";
}

function send_receipt_sms(array $appointment, array $clinic): array {
    global $pdo;

    $message = receipt_message($appointment, $clinic);
    $result = send_sms($appointment['phone'], $message, null, 'receipt', (int)$appointment['id']);

    if ($result['success']) {
        $stmt = $pdo->prepare("UPDATE appointments SET receipt_sent_sms=1 WHERE id=? AND clinic_id=?");
        $stmt->execute([$appointment['id'], $appointment['clinic_id']]);
    }

    return $result;
}

function send_receipt_whatsapp(array $appointment, array $clinic): array {
    global $pdo;

    $message = receipt_message($appointment, $clinic);
    $result = send_whatsapp_message($appointment['phone'], $message, (int)$appointment['id']);

    if ($result['success']) {
        $stmt = $pdo->prepare("UPDATE appointments SET receipt_sent_whatsapp=1 WHERE id=? AND clinic_id=?");
        $stmt->execute([$appointment['id'], $appointment['clinic_id']]);
    }

    return $result;
}
