-- Receipt / Invoice Upgrade Patch
ALTER TABLE appointments
ADD COLUMN receipt_no VARCHAR(100) NULL AFTER payment_reference;

ALTER TABLE appointments
ADD COLUMN receipt_sent_sms TINYINT(1) NOT NULL DEFAULT 0 AFTER receipt_no;

ALTER TABLE appointments
ADD COLUMN receipt_sent_whatsapp TINYINT(1) NOT NULL DEFAULT 0 AFTER receipt_sent_sms;

CREATE INDEX idx_appointments_receipt_no ON appointments(receipt_no);
