<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

if (!function_exists('ensure_receipt_number')) {
    require_once __DIR__ . '/../includes/receipt_helpers.php';
}

$clinicId = current_clinic_id();
$appointmentId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id=? AND clinic_id=? LIMIT 1");
$stmt->execute([$appointmentId, $clinicId]);
$appointment = $stmt->fetch();

if (!$appointment) {
    die('Appointment not found.');
}

$clinic = current_clinic();
$receiptNo = ensure_receipt_number($appointment);
$appointment['receipt_no'] = $receiptNo;

$pageTitle = 'Receipt ' . $receiptNo;

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/admin_nav.php';
?>

<style>
.receipt-wrap { max-width: 850px; margin: auto; }
.receipt-box {
    background: #fff;
    border-radius: 22px;
    padding: 35px;
    box-shadow: 0 12px 35px rgba(0,0,0,.08);
}
.receipt-header {
    border-bottom: 4px solid #810506;
    padding-bottom: 20px;
    margin-bottom: 25px;
}
.receipt-title { color: #810506; font-weight: 800; }
.receipt-table td { padding: 10px 0; border-bottom: 1px solid #eee; }
.receipt-total {
    background: #f2f3f5;
    border-left: 5px solid #810506;
    border-radius: 14px;
    padding: 18px;
}
@media print {
    .navbar, .admin-nav, .btn, .no-print { display: none !important; }
    body { background: #fff !important; }
    .page-wrapper { padding: 0 !important; }
    .receipt-box { box-shadow: none !important; border-radius: 0 !important; }
}
</style>

<div class="container py-4 receipt-wrap">

    <div class="no-print mb-3 d-flex gap-2 flex-wrap">
        <button onclick="window.print()" class="btn btn-primary">Print / Save as PDF</button>
        <a href="<?= BASE_URL ?>/admin/send_receipt.php?id=<?= e((string)$appointment['id']) ?>&type=sms" class="btn btn-success">Send SMS Receipt</a>
        <a href="<?= BASE_URL ?>/admin/send_receipt.php?id=<?= e((string)$appointment['id']) ?>&type=whatsapp" class="btn btn-outline-success">Send WhatsApp Receipt</a>
        <a href="<?= BASE_URL ?>/admin/appointments.php" class="btn btn-outline-secondary">Back</a>
    </div>

    <div class="receipt-box">

        <div class="receipt-header d-flex justify-content-between flex-wrap gap-3">
            <div>
                <h2 class="receipt-title mb-1"><?= e($clinic['clinic_name'] ?? 'Clinic') ?></h2>
                <div class="text-muted"><?= e($clinic['phone'] ?? '') ?></div>
                <div class="text-muted"><?= e($clinic['email'] ?? '') ?></div>
                <div class="text-muted"><?= e($clinic['address'] ?? '') ?></div>
            </div>

            <div class="text-end">
                <h4 class="fw-bold mb-1">PAYMENT RECEIPT</h4>
                <div>Receipt No: <strong><?= e($receiptNo) ?></strong></div>
                <div>Date: <strong><?= e(date('Y-m-d')) ?></strong></div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <h6 class="fw-bold">Client Details</h6>
                <table class="w-100 receipt-table">
                    <tr><td>Name</td><td class="text-end fw-bold"><?= e($appointment['full_name']) ?></td></tr>
                    <tr><td>Phone</td><td class="text-end"><?= e($appointment['phone']) ?></td></tr>
                </table>
            </div>

            <div class="col-md-6">
                <h6 class="fw-bold">Appointment Details</h6>
                <table class="w-100 receipt-table">
                    <tr><td>Service</td><td class="text-end fw-bold"><?= e($appointment['service_name'] ?: 'Appointment') ?></td></tr>
                    <tr><td>Date & Time</td><td class="text-end"><?= e($appointment['appointment_date']) ?> <?= e(substr($appointment['appointment_time'], 0, 5)) ?></td></tr>
                </table>
            </div>
        </div>

        <h6 class="fw-bold">Payment Summary</h6>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Description</th>
                    <th class="text-end">Amount</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?= e($appointment['service_name'] ?: 'Appointment Payment') ?></td>
                    <td class="text-end">KES <?= number_format((float)$appointment['payment_amount'], 2) ?></td>
                </tr>
            </tbody>
        </table>

        <div class="receipt-total mt-3">
            <div class="d-flex justify-content-between">
                <strong>Total Paid</strong>
                <strong>KES <?= number_format((float)$appointment['payment_amount'], 2) ?></strong>
            </div>

            <div class="small text-muted mt-2">
                Payment Method: <?= e($appointment['payment_method'] ?: 'M-Pesa / Cash') ?>
                <?php if (!empty($appointment['payment_reference'])): ?>
                    | Ref: <?= e($appointment['payment_reference']) ?>
                <?php endif; ?>
                <?php if (!empty($appointment['mpesa_receipt'])): ?>
                    | M-Pesa: <?= e($appointment['mpesa_receipt']) ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="text-center mt-4 text-muted small">
            Thank you for choosing <?= e($clinic['clinic_name'] ?? 'our clinic') ?>.
        </div>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
