<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

if (!function_exists('ensure_receipt_number')) {
    require_once __DIR__ . '/../includes/receipt_helpers.php';
}

$clinicId = current_clinic_id();
$appointmentId = (int)($_GET['id'] ?? 0);
$type = $_GET['type'] ?? 'sms';

$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id=? AND clinic_id=? LIMIT 1");
$stmt->execute([$appointmentId, $clinicId]);
$appointment = $stmt->fetch();

if (!$appointment) {
    flash('error', 'Appointment not found.');
    redirect(BASE_URL . '/admin/appointments.php');
}

$clinic = current_clinic();
$receiptNo = ensure_receipt_number($appointment);
$appointment['receipt_no'] = $receiptNo;

if ($type === 'whatsapp') {
    $result = send_receipt_whatsapp($appointment, $clinic);
    flash($result['success'] ? 'success' : 'error', $result['success'] ? 'WhatsApp receipt sent.' : 'WhatsApp receipt failed: ' . $result['message']);
} else {
    $result = send_receipt_sms($appointment, $clinic);
    flash($result['success'] ? 'success' : 'error', $result['success'] ? 'SMS receipt sent.' : 'SMS receipt failed: ' . $result['message']);
}

redirect(BASE_URL . '/admin/receipt.php?id=' . $appointmentId);
