<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

if (!function_exists('send_reschedule_notifications')) {
    require_once __DIR__ . '/../includes/reschedule_helpers.php';
}

$pageTitle = 'Reschedule Appointment';
$clinicId = current_clinic_id();
$clinic = current_clinic();

if (!$clinic) {
    die('Clinic not found.');
}

$appointmentId = (int)($_GET['id'] ?? $_POST['appointment_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id=? AND clinic_id=? LIMIT 1");
$stmt->execute([$appointmentId, $clinicId]);
$appointment = $stmt->fetch();

if (!$appointment) {
    flash('error', 'Appointment not found.');
    redirect(BASE_URL . '/admin/appointments.php');
}

$serviceId = (int)($appointment['service_id'] ?? 0);

if ($serviceId <= 0 && !empty($appointment['service_name'])) {
    $svc = $pdo->prepare("SELECT id FROM services WHERE clinic_id=? AND service_name=? LIMIT 1");
    $svc->execute([$clinicId, $appointment['service_name']]);
    $serviceId = (int)$svc->fetchColumn();
}

$stmt = $pdo->prepare("SELECT * FROM services WHERE clinic_id=? AND status='Active' ORDER BY service_name ASC");
$stmt->execute([$clinicId]);
$services = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        !isset($_POST['csrf_token']) ||
        !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])
    ) {
        die('Invalid CSRF token.');
    }

    $newServiceId = (int)($_POST['service_id'] ?? 0);
    $newDate = trim($_POST['appointment_date'] ?? '');
    $newTime = trim($_POST['appointment_time'] ?? '');
    $reason = trim($_POST['reschedule_reason'] ?? '');

    if (!$newServiceId || !$newDate || !$newTime) {
        flash('error', 'Please select service, date, and available time.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    $stmt = $pdo->prepare("SELECT * FROM services WHERE id=? AND clinic_id=? AND status='Active' LIMIT 1");
    $stmt->execute([$newServiceId, $clinicId]);
    $service = $stmt->fetch();

    if (!$service) {
        flash('error', 'Invalid service selected.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    if ($newDate < date('Y-m-d')) {
        flash('error', 'Date cannot be in the past.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    if (!clinic_is_open_on($newDate, $clinicId)) {
        flash('error', 'Clinic is closed on the selected date.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    $cleanTime = substr($newTime, 0, 5);
    $appointmentTime = $cleanTime . ':00';

    $durationMinutes = (int)($service['duration_minutes'] ?? 30);
    $slotMinutes = (int)($service['slot_minutes'] ?? 30);

    $allowedSlots = array_column(
        available_slots_for_date($newDate, $clinicId, $slotMinutes, $durationMinutes, $appointmentId),
        'time'
    );

    if (!in_array($cleanTime, $allowedSlots, true)) {
        flash('error', 'Please choose a valid available slot.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    if (has_appointment_conflict($newDate, $appointmentTime, $clinicId, $durationMinutes, $appointmentId)) {
        flash('error', 'That slot is already taken.');
        redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
    }

    $oldDate = $appointment['appointment_date'];
    $oldTime = $appointment['appointment_time'];

    $update = $pdo->prepare("
        UPDATE appointments
        SET
            previous_appointment_date=?,
            previous_appointment_time=?,
            appointment_date=?,
            appointment_time=?,
            service_id=?,
            service_name=?,
            service_price=?,
            service_duration=?,
            payment_amount=?,
            status='Confirmed',
            reschedule_reason=?,
            reschedule_count=reschedule_count+1,
            last_rescheduled_at=NOW(),
            reminder_24h_sent=0,
            reminder_2h_sent=0,
            missed_sms_sent=0,
            updated_at=NOW()
        WHERE id=? AND clinic_id=?
    ");

    $update->execute([
        $oldDate,
        $oldTime,
        $newDate,
        $appointmentTime,
        (int)$service['id'],
        $service['service_name'],
        (float)$service['price'],
        (int)$service['duration_minutes'],
        (float)$service['price'],
        $reason,
        $appointmentId,
        $clinicId
    ]);

    $stmt = $pdo->prepare("SELECT * FROM appointments WHERE id=? AND clinic_id=? LIMIT 1");
    $stmt->execute([$appointmentId, $clinicId]);
    $updatedAppointment = $stmt->fetch();

    $notify = send_reschedule_notifications($updatedAppointment, $clinic, $oldDate, $oldTime);

    flash($notify['success'] ? 'success' : 'error', 'Appointment rescheduled. ' . $notify['message']);
    redirect(BASE_URL . '/admin/reschedule.php?id=' . $appointmentId);
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$clinicSlug = $clinic['slug'] ?? '';
$pageTitle = 'Reschedule Appointment';

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/admin_nav.php';
?>

<div class="container-fluid py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">

            <div class="card mobile-card">
                <div class="card-body p-4">

                    <h3 class="fw-bold mb-1">Reschedule Appointment</h3>
                    <p class="text-muted">
                        Choose a new available slot. Client will receive SMS/WhatsApp update.
                    </p>

                    <?php if ($msg = flash('error')): ?>
                        <div class="alert alert-danger"><?= e($msg) ?></div>
                    <?php endif; ?>

                    <?php if ($msg = flash('success')): ?>
                        <div class="alert alert-success"><?= e($msg) ?></div>
                    <?php endif; ?>

                    <div class="alert alert-light border">
                        <strong><?= e($appointment['full_name']) ?></strong><br>
                        <?= e($appointment['phone']) ?><br>
                        Current: <?= e($appointment['appointment_date']) ?> <?= e(substr($appointment['appointment_time'], 0, 5)) ?><br>
                        Service: <?= e($appointment['service_name'] ?: 'N/A') ?>
                    </div>

                    <form method="post">
                        <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                        <input type="hidden" name="appointment_id" value="<?= e((string)$appointmentId) ?>">

                        <div class="mb-3">
                            <label class="form-label">Service</label>
                            <select name="service_id" id="service_id" class="form-select" required>
                                <option value="">Choose service</option>
                                <?php foreach ($services as $service): ?>
                                    <option
                                        value="<?= e((string)$service['id']) ?>"
                                        data-price="<?= e((string)$service['price']) ?>"
                                        data-duration="<?= e((string)$service['duration_minutes']) ?>"
                                        <?= ((int)$service['id'] === $serviceId) ? 'selected' : '' ?>
                                    >
                                        <?= e($service['service_name']) ?> - KES <?= number_format((float)$service['price'], 2) ?> / <?= e((string)$service['duration_minutes']) ?> mins
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">New Date</label>
                                <input type="date" name="appointment_date" id="appointment_date" class="form-control" min="<?= date('Y-m-d') ?>" value="<?= e($appointment['appointment_date']) ?>" required>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label">New Available Time</label>
                                <select name="appointment_time" id="appointment_time" class="form-select" required>
                                    <option value="">Select date and service first</option>
                                </select>
                            </div>
                        </div>

                        <div class="mt-3">
                            <label class="form-label">Reason / Note</label>
                            <textarea name="reschedule_reason" class="form-control" rows="3" placeholder="Optional reason for reschedule"></textarea>
                        </div>

                        <button class="btn btn-success btn-lg w-100 mt-4" onclick="return confirm('Reschedule this appointment and notify client?')">
                            Reschedule & Notify Client
                        </button>

                        <a href="<?= BASE_URL ?>/admin/appointments.php" class="btn btn-outline-secondary w-100 mt-2">
                            Back to Appointments
                        </a>
                    </form>

                </div>
            </div>

        </div>
    </div>
</div>

<script>
const clinicSlug = <?= json_encode($clinicSlug) ?>;
const baseUrl = <?= json_encode(rtrim(BASE_URL, '/')) ?>;
const appointmentId = <?= json_encode($appointmentId) ?>;

const serviceSelect = document.getElementById('service_id');
const dateInput = document.getElementById('appointment_date');
const timeSelect = document.getElementById('appointment_time');
const currentTime = <?= json_encode(substr($appointment['appointment_time'], 0, 5)) ?>;
const currentDate = <?= json_encode($appointment['appointment_date']) ?>;

function loadSlots() {
    const serviceId = serviceSelect.value;
    const date = dateInput.value;

    if (!serviceId || !date) {
        timeSelect.innerHTML = '<option value="">Select date and service first</option>';
        return;
    }

    timeSelect.innerHTML = '<option value="">Loading slots...</option>';

    fetch(`${baseUrl}/api/available_slots.php?clinic=${encodeURIComponent(clinicSlug)}&date=${encodeURIComponent(date)}&service_id=${encodeURIComponent(serviceId)}&exclude_id=${encodeURIComponent(appointmentId)}`)
        .then(response => response.json())
        .then(data => {
            timeSelect.innerHTML = '';

            if (!data.success || !data.slots || data.slots.length === 0) {
                timeSelect.innerHTML = '<option value="">No slots available</option>';
                return;
            }

            timeSelect.innerHTML = '<option value="">Choose time</option>';

            data.slots.forEach(slot => {
                const option = document.createElement('option');
                option.value = slot.time;
                option.textContent = slot.label || slot.time;

                if (date === currentDate && slot.time === currentTime) {
                    option.selected = true;
                }

                timeSelect.appendChild(option);
            });
        })
        .catch(() => {
            timeSelect.innerHTML = '<option value="">Could not load slots</option>';
        });
}

serviceSelect.addEventListener('change', loadSlots);
dateInput.addEventListener('change', loadSlots);
loadSlots();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
