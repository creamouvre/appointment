<?php
/*
|--------------------------------------------------------------------------
| RESCHEDULE HELPER FUNCTIONS
|--------------------------------------------------------------------------
| Include in config/config.php if needed:
| require_once __DIR__ . '/../includes/reschedule_helpers.php';
|--------------------------------------------------------------------------
*/

function appointment_reschedule_message(array $appointment, array $clinic, string $oldDate, string $oldTime): string {
    $service = !empty($appointment['service_name']) ? ' for ' . $appointment['service_name'] : '';
    $clinicName = $clinic['clinic_name'] ?? setting('site_name', 'Clinic');

    return 'Hello ' . $appointment['full_name'] . ', your appointment' . $service . ' at ' . $clinicName
        . ' has been rescheduled from ' . $oldDate . ' at ' . substr($oldTime, 0, 5)
        . ' to ' . $appointment['appointment_date'] . ' at ' . substr($appointment['appointment_time'], 0, 5)
        . '. Thank you.';
}

function send_reschedule_notifications(array $appointment, array $clinic, string $oldDate, string $oldTime): array {
    global $pdo;

    $message = appointment_reschedule_message($appointment, $clinic, $oldDate, $oldTime);
    $results = [];

    $sms = send_sms($appointment['phone'], $message, null, 'reschedule', (int)$appointment['id']);

    if ($sms['success']) {
        $stmt = $pdo->prepare("UPDATE appointments SET reschedule_sms_sent=1 WHERE id=? AND clinic_id=?");
        $stmt->execute([$appointment['id'], $appointment['clinic_id']]);
    }

    $results[] = 'SMS: ' . ($sms['success'] ? 'sent' : 'failed (' . $sms['message'] . ')');

    $wa = send_whatsapp_message($appointment['phone'], $message, (int)$appointment['id']);

    if ($wa['success']) {
        $stmt = $pdo->prepare("UPDATE appointments SET reschedule_whatsapp_sent=1 WHERE id=? AND clinic_id=?");
        $stmt->execute([$appointment['id'], $appointment['clinic_id']]);
    }

    $results[] = 'WhatsApp: ' . ($wa['success'] ? 'sent' : 'not sent (' . $wa['message'] . ')');

    return [
        'success' => $sms['success'] || $wa['success'],
        'message' => implode(' | ', $results)
    ];
}
