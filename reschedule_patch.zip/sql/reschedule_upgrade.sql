-- Reschedule Upgrade Patch
-- Run one by one if your MySQL version complains.

ALTER TABLE appointments
ADD COLUMN reschedule_count INT NOT NULL DEFAULT 0 AFTER admin_note;

ALTER TABLE appointments
ADD COLUMN last_rescheduled_at DATETIME NULL AFTER reschedule_count;

ALTER TABLE appointments
ADD COLUMN previous_appointment_date DATE NULL AFTER last_rescheduled_at;

ALTER TABLE appointments
ADD COLUMN previous_appointment_time TIME NULL AFTER previous_appointment_date;

ALTER TABLE appointments
ADD COLUMN reschedule_reason TEXT NULL AFTER previous_appointment_time;

ALTER TABLE appointments
ADD COLUMN reschedule_sms_sent TINYINT(1) NOT NULL DEFAULT 0 AFTER reschedule_reason;

ALTER TABLE appointments
ADD COLUMN reschedule_whatsapp_sent TINYINT(1) NOT NULL DEFAULT 0 AFTER reschedule_sms_sent;
