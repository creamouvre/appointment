<?php
require_once __DIR__ . '/../config/config.php';

header('Content-Type: application/json');

$clinicSlug = trim($_GET['clinic'] ?? '');
$date = trim($_GET['date'] ?? '');
$serviceId = (int)($_GET['service_id'] ?? 0);
$excludeId = (int)($_GET['exclude_id'] ?? 0);

if ($clinicSlug === '' || $date === '' || $serviceId <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing clinic, date, or service.'
    ]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM clinics WHERE slug=? AND status='Active' LIMIT 1");
$stmt->execute([$clinicSlug]);
$clinic = $stmt->fetch();

if (!$clinic) {
    echo json_encode([
        'success' => false,
        'message' => 'Clinic not found or inactive.'
    ]);
    exit;
}

$clinicId = (int)$clinic['id'];

$stmt = $pdo->prepare("SELECT * FROM services WHERE id=? AND clinic_id=? AND status='Active' LIMIT 1");
$stmt->execute([$serviceId, $clinicId]);
$service = $stmt->fetch();

if (!$service) {
    echo json_encode([
        'success' => false,
        'message' => 'Service not found.'
    ]);
    exit;
}

if ($date < date('Y-m-d')) {
    echo json_encode([
        'success' => false,
        'message' => 'Date cannot be in the past.'
    ]);
    exit;
}

if (!clinic_is_open_on($date, $clinicId)) {
    echo json_encode([
        'success' => true,
        'slots' => [],
        'message' => 'Clinic is closed on this date.'
    ]);
    exit;
}

$slotMinutes = (int)($service['slot_minutes'] ?? 30);
$durationMinutes = (int)($service['duration_minutes'] ?? 30);

$slots = available_slots_for_date($date, $clinicId, $slotMinutes, $durationMinutes, $excludeId);

echo json_encode([
    'success' => true,
    'slots' => $slots
]);
