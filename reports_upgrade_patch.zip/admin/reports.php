<?php
require_once __DIR__ . '/../config/config.php';
require_admin();

$pageTitle = 'Reports';
$clinicId = current_clinic_id();

$from = trim($_GET['from'] ?? date('Y-m-01'));
$to = trim($_GET['to'] ?? date('Y-m-t'));
$status = trim($_GET['status'] ?? '');
$paymentStatus = trim($_GET['payment_status'] ?? '');
$serviceId = (int)($_GET['service_id'] ?? 0);

$where = " WHERE clinic_id = :clinic_id ";
$params = [':clinic_id' => $clinicId];

if ($from !== '') {
    $where .= " AND appointment_date >= :from ";
    $params[':from'] = $from;
}

if ($to !== '') {
    $where .= " AND appointment_date <= :to ";
    $params[':to'] = $to;
}

if ($status !== '') {
    $where .= " AND status = :status ";
    $params[':status'] = $status;
}

if ($paymentStatus !== '') {
    $where .= " AND payment_status = :payment_status ";
    $params[':payment_status'] = $paymentStatus;
}

if ($serviceId > 0) {
    $where .= " AND service_id = :service_id ";
    $params[':service_id'] = $serviceId;
}

function fetch_all_report(string $sql, array $params): array {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function fetch_one_report(string $sql, array $params) {
    global $pdo;
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn();
}

/*
|--------------------------------------------------------------------------
| SUMMARY CARDS
|--------------------------------------------------------------------------
*/
$totalAppointments = (int)fetch_one_report("SELECT COUNT(*) FROM appointments {$where}", $params);
$totalEnquiries = (int)fetch_one_report("SELECT COUNT(*) FROM appointments {$where} AND status='Enquiry'", $params);
$totalPaid = (int)fetch_one_report("SELECT COUNT(*) FROM appointments {$where} AND payment_status='Paid'", $params);
$totalCompleted = (int)fetch_one_report("SELECT COUNT(*) FROM appointments {$where} AND status='Completed'", $params);
$totalMissed = (int)fetch_one_report("SELECT COUNT(*) FROM appointments {$where} AND status='Missed'", $params);
$totalRevenue = (float)fetch_one_report("SELECT COALESCE(SUM(payment_amount),0) FROM appointments {$where} AND payment_status='Paid'", $params);

$enquiryToPaid = $totalEnquiries > 0 ? round(($totalPaid / $totalEnquiries) * 100, 1) : 0;
$noShowRate = $totalAppointments > 0 ? round(($totalMissed / $totalAppointments) * 100, 1) : 0;

/*
|--------------------------------------------------------------------------
| SERVICES
|--------------------------------------------------------------------------
*/
$serviceStmt = $pdo->prepare("SELECT id, service_name FROM services WHERE clinic_id=? ORDER BY service_name ASC");
$serviceStmt->execute([$clinicId]);
$services = $serviceStmt->fetchAll();

/*
|--------------------------------------------------------------------------
| REVENUE BY SERVICE
|--------------------------------------------------------------------------
*/
$revenueByService = fetch_all_report("
    SELECT 
        COALESCE(service_name, 'No Service') AS service_name,
        COUNT(*) AS total_appointments,
        SUM(CASE WHEN payment_status='Paid' THEN 1 ELSE 0 END) AS paid_count,
        COALESCE(SUM(CASE WHEN payment_status='Paid' THEN payment_amount ELSE 0 END),0) AS revenue
    FROM appointments
    {$where}
    GROUP BY COALESCE(service_name, 'No Service')
    ORDER BY revenue DESC
", $params);

/*
|--------------------------------------------------------------------------
| REVENUE BY MONTH
|--------------------------------------------------------------------------
*/
$revenueByMonth = fetch_all_report("
    SELECT 
        DATE_FORMAT(appointment_date, '%Y-%m') AS month_label,
        COUNT(*) AS appointments,
        COALESCE(SUM(CASE WHEN payment_status='Paid' THEN payment_amount ELSE 0 END),0) AS revenue
    FROM appointments
    {$where}
    GROUP BY DATE_FORMAT(appointment_date, '%Y-%m')
    ORDER BY month_label ASC
", $params);

/*
|--------------------------------------------------------------------------
| BUSIEST DAYS
|--------------------------------------------------------------------------
*/
$busiestDays = fetch_all_report("
    SELECT 
        DAYNAME(appointment_date) AS day_name,
        COUNT(*) AS total
    FROM appointments
    {$where}
    GROUP BY DAYNAME(appointment_date), DAYOFWEEK(appointment_date)
    ORDER BY DAYOFWEEK(appointment_date)
", $params);

/*
|--------------------------------------------------------------------------
| BUSIEST HOURS
|--------------------------------------------------------------------------
*/
$busiestHours = fetch_all_report("
    SELECT 
        DATE_FORMAT(appointment_time, '%H:00') AS hour_label,
        COUNT(*) AS total
    FROM appointments
    {$where}
    GROUP BY DATE_FORMAT(appointment_time, '%H')
    ORDER BY hour_label ASC
", $params);

/*
|--------------------------------------------------------------------------
| RETURNING CLIENTS
|--------------------------------------------------------------------------
*/
$returningClients = fetch_all_report("
    SELECT 
        c.id,
        c.full_name,
        c.phone,
        COUNT(a.id) AS appointment_count,
        COALESCE(SUM(CASE WHEN a.payment_status='Paid' THEN a.payment_amount ELSE 0 END),0) AS total_paid,
        MAX(a.appointment_date) AS last_appointment
    FROM clients c
    JOIN appointments a ON a.client_id = c.id AND a.clinic_id = c.clinic_id
    {$where}
    AND c.clinic_id = :client_clinic_id
    GROUP BY c.id, c.full_name, c.phone
    HAVING COUNT(a.id) > 1
    ORDER BY appointment_count DESC, total_paid DESC
    LIMIT 20
", array_merge($params, [':client_clinic_id' => $clinicId]));

/*
|--------------------------------------------------------------------------
| STATUS BREAKDOWN
|--------------------------------------------------------------------------
*/
$statusBreakdown = fetch_all_report("
    SELECT status, COUNT(*) AS total
    FROM appointments
    {$where}
    GROUP BY status
    ORDER BY total DESC
", $params);

/*
|--------------------------------------------------------------------------
| PAYMENT BREAKDOWN
|--------------------------------------------------------------------------
*/
$paymentBreakdown = fetch_all_report("
    SELECT payment_status, COUNT(*) AS total
    FROM appointments
    {$where}
    GROUP BY payment_status
    ORDER BY total DESC
", $params);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/admin_nav.php';
?>

<div class="container-fluid py-4">

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
        <div>
            <h3 class="fw-bold mb-1">Reports & Analytics</h3>
            <p class="text-muted mb-0">Revenue, conversions, no-shows, busy times, and returning clients.</p>
        </div>
    </div>

    <div class="card mobile-card mb-4">
        <div class="card-body">
            <form method="get" class="row g-3 align-items-end">
                <div class="col-md-2">
                    <label class="form-label">From</label>
                    <input type="date" name="from" class="form-control" value="<?= e($from) ?>">
                </div>

                <div class="col-md-2">
                    <label class="form-label">To</label>
                    <input type="date" name="to" class="form-control" value="<?= e($to) ?>">
                </div>

                <div class="col-md-2">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select">
                        <option value="">All</option>
                        <?php foreach (['Enquiry','Pending','Confirmed','Completed','Cancelled','Reschedule Needed','Missed'] as $s): ?>
                            <option value="<?= e($s) ?>" <?= $status === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Payment</label>
                    <select name="payment_status" class="form-select">
                        <option value="">All</option>
                        <?php foreach (['Paid','Unpaid'] as $p): ?>
                            <option value="<?= e($p) ?>" <?= $paymentStatus === $p ? 'selected' : '' ?>><?= e($p) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label">Service</label>
                    <select name="service_id" class="form-select">
                        <option value="0">All</option>
                        <?php foreach ($services as $service): ?>
                            <option value="<?= e((string)$service['id']) ?>" <?= $serviceId === (int)$service['id'] ? 'selected' : '' ?>>
                                <?= e($service['service_name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="col-md-2 d-grid">
                    <button class="btn btn-primary">Apply Filter</button>
                </div>
            </form>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <?php foreach ([
            ['Total Appointments', $totalAppointments],
            ['Revenue', 'KES ' . number_format($totalRevenue, 2)],
            ['Paid Appointments', $totalPaid],
            ['Completed', $totalCompleted],
            ['No-show Rate', $noShowRate . '%'],
            ['Enquiry → Paid', $enquiryToPaid . '%'],
        ] as $item): ?>
            <div class="col-6 col-lg-2">
                <div class="card card-stat h-100">
                    <div class="card-body">
                        <div class="text-muted small"><?= e($item[0]) ?></div>
                        <div class="h3 fw-bold"><?= e((string)$item[1]) ?></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-lg-7">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Revenue by Month</h5>
                    <div style="height:330px"><canvas id="revenueMonthChart"></canvas></div>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Revenue by Service</h5>
                    <div style="height:330px"><canvas id="serviceRevenueChart"></canvas></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Busiest Days</h5>
                    <div style="height:300px"><canvas id="busiestDaysChart"></canvas></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Busiest Hours</h5>
                    <div style="height:300px"><canvas id="busiestHoursChart"></canvas></div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Status Breakdown</h5>
                    <div style="height:300px"><canvas id="statusChart"></canvas></div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card mobile-card">
                <div class="card-body">
                    <h5 class="fw-bold">Payment Breakdown</h5>
                    <div style="height:300px"><canvas id="paymentChart"></canvas></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card mobile-card mb-4">
        <div class="card-body">
            <h5 class="fw-bold mb-3">Revenue by Service</h5>

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead>
                        <tr>
                            <th>Service</th>
                            <th>Total Appointments</th>
                            <th>Paid Count</th>
                            <th class="text-end">Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($revenueByService as $row): ?>
                            <tr>
                                <td><?= e($row['service_name']) ?></td>
                                <td><?= e((string)$row['total_appointments']) ?></td>
                                <td><?= e((string)$row['paid_count']) ?></td>
                                <td class="text-end">KES <?= number_format((float)$row['revenue'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (!$revenueByService): ?>
                            <tr><td colspan="4" class="text-center text-muted">No data found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mobile-card">
        <div class="card-body">
            <h5 class="fw-bold mb-3">Returning Clients</h5>

            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead>
                        <tr>
                            <th>Client</th>
                            <th>Phone</th>
                            <th>Appointments</th>
                            <th>Last Appointment</th>
                            <th class="text-end">Total Paid</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($returningClients as $row): ?>
                            <tr>
                                <td>
                                    <a href="<?= BASE_URL ?>/admin/client_profile.php?id=<?= e((string)$row['id']) ?>">
                                        <?= e($row['full_name']) ?>
                                    </a>
                                </td>
                                <td><?= e($row['phone']) ?></td>
                                <td><?= e((string)$row['appointment_count']) ?></td>
                                <td><?= e($row['last_appointment'] ?? '') ?></td>
                                <td class="text-end">KES <?= number_format((float)$row['total_paid'], 2) ?></td>
                            </tr>
                        <?php endforeach; ?>

                        <?php if (!$returningClients): ?>
                            <tr><td colspan="5" class="text-center text-muted">No returning clients found in this period.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
const revenueMonthLabels = <?= json_encode(array_column($revenueByMonth, 'month_label')) ?>;
const revenueMonthData = <?= json_encode(array_map('floatval', array_column($revenueByMonth, 'revenue'))) ?>;
const revenueMonthAppointments = <?= json_encode(array_map('intval', array_column($revenueByMonth, 'appointments'))) ?>;

new Chart(document.getElementById('revenueMonthChart'), {
    type: 'bar',
    data: {
        labels: revenueMonthLabels,
        datasets: [
            { label: 'Revenue', data: revenueMonthData, yAxisID: 'y' },
            { label: 'Appointments', data: revenueMonthAppointments, type: 'line', yAxisID: 'y1' }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: { beginAtZero: true },
            y1: { beginAtZero: true, position: 'right', grid: { drawOnChartArea: false } }
        }
    }
});

const serviceLabels = <?= json_encode(array_column($revenueByService, 'service_name')) ?>;
const serviceRevenue = <?= json_encode(array_map('floatval', array_column($revenueByService, 'revenue'))) ?>;

new Chart(document.getElementById('serviceRevenueChart'), {
    type: 'bar',
    data: {
        labels: serviceLabels,
        datasets: [{ label: 'Revenue', data: serviceRevenue }]
    },
    options: { responsive: true, maintainAspectRatio: false, indexAxis: 'y' }
});

const dayLabels = <?= json_encode(array_column($busiestDays, 'day_name')) ?>;
const dayTotals = <?= json_encode(array_map('intval', array_column($busiestDays, 'total'))) ?>;

new Chart(document.getElementById('busiestDaysChart'), {
    type: 'bar',
    data: {
        labels: dayLabels,
        datasets: [{ label: 'Appointments', data: dayTotals }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

const hourLabels = <?= json_encode(array_column($busiestHours, 'hour_label')) ?>;
const hourTotals = <?= json_encode(array_map('intval', array_column($busiestHours, 'total'))) ?>;

new Chart(document.getElementById('busiestHoursChart'), {
    type: 'bar',
    data: {
        labels: hourLabels,
        datasets: [{ label: 'Appointments', data: hourTotals }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

const statusLabels = <?= json_encode(array_column($statusBreakdown, 'status')) ?>;
const statusTotals = <?= json_encode(array_map('intval', array_column($statusBreakdown, 'total'))) ?>;

new Chart(document.getElementById('statusChart'), {
    type: 'doughnut',
    data: {
        labels: statusLabels,
        datasets: [{ data: statusTotals }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});

const paymentLabels = <?= json_encode(array_column($paymentBreakdown, 'payment_status')) ?>;
const paymentTotals = <?= json_encode(array_map('intval', array_column($paymentBreakdown, 'total'))) ?>;

new Chart(document.getElementById('paymentChart'), {
    type: 'doughnut',
    data: {
        labels: paymentLabels,
        datasets: [{ data: paymentTotals }]
    },
    options: { responsive: true, maintainAspectRatio: false }
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
